# Manuscript review

Compile `human_readable_main.tex` for Johanna’s manuscript review. `main.tex`
forwards to that same annotated source, so either entry point produces the
selected paper. Red additions and blue struck originals preserve the proposed
local corrections; the comment boxes give their justifications. Author
acceptance remains pending. The current source is paper P5
`75f79630141f2bbeedc4e154288978020c7f2e83`, public snapshot S5
`973fa2831cf7520fc42566587e3946b4b7444093`; P5 changes citations only from P4.
The three matching P5 PDFs compiled with zero undefined citations, references and control sequences; see `docs/paper-lean-audit/review-pdfs.json`.

Compile `lean_proof_details.tex` for the mathematical accounts supporting
Max’s paper-to-Lean review. The formal v1.3.1 proof and all four local Palomar comparisons passed; its
verified archive is https://doi.org/10.5281/zenodo.23127367. Johanna’s manuscript review
and Max’s complete paper-to-Lean correspondence review remain pending.

Build the selected paper with `latexmk -pdf human_readable_main.tex`. Build
the companion afterward with `latexmk -pdf lean_proof_details.tex`, which
uses the paper’s cross-reference file.

Earlier complete drafts and proof maps are retained in
[the historical archive](archive/historical-proof-drafts/README.md). They
are outside the current review assignment.

Both releases are archived and byte-verified: formal [v1.3.0](https://doi.org/10.5281/zenodo.23126868) and supplementary [v0.2.0](https://doi.org/10.5281/zenodo.23127103). The [current review ledger](docs/review-status.json) records the final P5/S5 inputs and pending human responsibilities. Max starts the [guided comparison](https://itpplasma.github.io/stafford38-formal/), checks all57 cards including hypotheses, definitions, supporting proofs and both shared challenges/solution variants, and exports findings JSON. Johanna reviews the marked proposals on Overleaf.
