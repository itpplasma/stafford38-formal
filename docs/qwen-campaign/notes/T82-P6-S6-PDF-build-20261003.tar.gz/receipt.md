# P6/S6 PDF build receipt

Paper origin P6 `33138378368fdc9f7bcb50947ccc9889f40cac43`; public snapshot S6 `0bb3aa929b931bf5d82d90f62d7508d3ae1dccc1`. Formal source R is v1.3.1 `f9448d6307fa25aff9d9f94ce0a9c7f9b03e63ff`, DOI `10.5281/zenodo.23127367`.

The three PDFs were compiled once, in README order, with `latexmk -pdf -interaction=nonstopmode -halt-on-error`. All exited 0 and all TeX logs have zero undefined citations, references, or control sequences. The exact five TeX/Bib compilation inputs matched before and after; the README instruction hash is separate. LICENSE.txt was copied after compilation as licensing-only source-packet material. The three output hashes and exact source pins are in `review-pdfs.json`.

Human correspondence reviews remain pending.
