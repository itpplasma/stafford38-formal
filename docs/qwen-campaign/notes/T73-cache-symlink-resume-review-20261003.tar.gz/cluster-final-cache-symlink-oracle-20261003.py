import os,subprocess,tempfile
from pathlib import Path
s=Path('/tmp/cluster-final-cache-symlink-resume-20261003.sh').read_text()
shell=s
manifest=s.split('python3 - "$source_root" "$source_commit" "$target" "$expected" <<\'PY\'\n',1)[1].split('\nPY\n}',1)[0]
with tempfile.TemporaryDirectory() as t:
 r=Path(t)/'source';r.mkdir();donor=Path(t)/'donor';donor.mkdir()
 def git(*a):return subprocess.check_output(['git','-C',str(r),*a],text=True).strip()
 git('init','-q');git('config','user.email','oracle@example.invalid');git('config','user.name','Oracle')
 (r/'.gitignore').write_text('.lake/\n');(r/'source').write_text('original\n');(r/'tool').write_text('tool\n');(r/'tool').chmod(0o755)
 git('add','.');git('commit','-qm','baseline');commit=git('rev-parse','HEAD');git('config','core.filemode','false')
 (r/'.lake').symlink_to(donor,target_is_directory=True)
 assert git('status','--porcelain=v1','--untracked-files=all')=='?? .lake'
 ex=r/'.git/info/exclude';ex.write_text(ex.read_text()+'\n/.lake\n')
 assert git('status','--porcelain=v1','--untracked-files=all')==''
 assert (r/'.lake').resolve(strict=True)==donor.resolve(strict=True)
 def check(ok):
  p=subprocess.run(['python3','-',str(r),commit,str(Path(t)/'manifest.json'),''],input=manifest,text=True,capture_output=True)
  assert (p.returncode==0)==ok,(p.returncode,p.stderr)
 check(True)
 (r/'source').write_text('tampered\n');check(False);(r/'source').write_text('original\n')
 (r/'tool').chmod(0o644);check(False);(r/'tool').chmod(0o755)
 (r/'source').chmod(0o755);check(False);(r/'source').chmod(0o644)
 (r/'other-untracked').write_text('x');check(False);(r/'other-untracked').unlink()
 (r/'.lake').unlink();(r/'.lake').symlink_to(Path(t),target_is_directory=True)
 cache_checks=shell.split("cache=source/'.lake'; donor=root/'final-source/.lake'",1)[1].split('\nPYRESUME',1)[0]
 try:
  exec(cache_checks,{'cache':r/'.lake','donor':donor,'root':Path(t)})
 except AssertionError:
  pass
 else:
  raise AssertionError('driver accepted wrong cache target')
 print('PASS: directory ignore misses symlink; exact metadata exclusion works; tracked byte and both exec-mode tampering rejected with core.filemode=false; other untracked file rejected; wrong cache target differs.')
