# Manuscript review

Compile `human_readable_main.tex` for Johanna’s manuscript review. `main.tex`
forwards to that same annotated source, so either entry point produces the
selected paper. Red additions and blue struck originals preserve the proposed
local corrections; the comment boxes give their justifications. Author
acceptance remains pending.

Compile `lean_proof_details.tex` for the mathematical accounts supporting
Max’s paper-to-Lean review. The formal v1.3.0 proof and all four local Palomar comparisons passed; its
verified archive is https://doi.org/10.5281/zenodo.23126868. Johanna’s manuscript review
and Max’s complete paper-to-Lean correspondence review remain pending.

Build the selected paper with `latexmk -pdf human_readable_main.tex`. Build
the companion afterward with `latexmk -pdf lean_proof_details.tex`, which
uses the paper’s cross-reference file.

Earlier complete drafts and proof maps are retained in
[the historical archive](archive/historical-proof-drafts/README.md). They
are outside the current review assignment.
