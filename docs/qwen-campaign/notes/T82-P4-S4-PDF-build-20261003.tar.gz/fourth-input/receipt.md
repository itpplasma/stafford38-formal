# Paper PDF compilation receipt — P4/S4

Status: all three PDFs compiled successfully from the exact P4 paper inputs. This receipt records PDF builds and source identity; the formal verifier, four actual Palomar comparisons, archive verification, and 399-name review-map compiler checks are recorded separately at their accepted source snapshots. Johanna’s and Max’s human reviews remain pending.

## Source identities

- Paper origin P4: `4d19a183846beb50f37ad2b4e51e836a76ed8bac` (`itpplasma/stafford38-paper`)
- Public formal snapshot S4: `2fde6c6311b9cc2e8b789649132ff87bdbcdb3d5` (`itpplasma/stafford38-formal`)
- Formal release source R: `54c4f0c902bcd840e44eeba80686ef3fa0e7dc2b` (v1.3.0; DOI `10.5281/zenodo.23126868`, archive check 1,163 files / zero mismatches)
- AlgebraicAnalysis: `bbbbf3fc358ca8100b158cec4cf47f336ab70163`
- The public S4 manuscript snapshot at `docs/paper-lean-audit/manuscript/human_readable_main.tex` has the same SHA-256 as P4’s `human_readable_main.tex`: `a6a50d1a46fccb964ba72a0f60a85aec46b4d20e7d17e7a248dd152e62c87a88`.
- P4 differs from P3’s `human_readable_main.tex` only at the marked AI archive citation on line 174, updated to cite the verified v1.3.0 archive; author proof text is unchanged. Proposed proof corrections remain marked review material.

## Inputs and manifests

The five TeX/bibliography compile inputs are `human_readable_main.tex`, `main.tex`, `ai_review.tex`, `lean_proof_details.tex`, and `references.bib`. Their exact P4 SHA-256 values are in `compilation-inputs-before.sha256` and `compilation-inputs-after.sha256`; the manifests match byte for byte (manifest SHA-256 `0eab014a2945741bb4da415abee74e72e04a29fe2f9e837c1dad8f2db79d36c5`).

`README.md` supplied build instructions and has SHA-256 `683aeafc367b369a313c2eaaad74f2bb67d17cbc253927206f447205998edde0`. `LICENSE.txt` (SHA-256 `98b6fde2693d4044dce4a071640e90bd8d250dd789d9033dbd5b77c79f389de4`) was copied from P4 after compilation as the sixth source-packet file; it is licensing material, not a TeX compile input. The initial six-file packet manifest also includes README separately and is retained as `inputs-before.sha256` / `inputs-after.sha256`.

## Build commands

Toolchain: latexmk 4.87 (15 June 2025), pdfTeX 3.141592653-2.6-1.40.29 (TeX Live 2026/Arch Linux). Commands ran sequentially in README order with halt-on-error:

1. `latexmk -pdf -interaction=nonstopmode -halt-on-error human_readable_main.tex` — exit 0.
2. `latexmk -pdf -interaction=nonstopmode -halt-on-error lean_proof_details.tex` — exit 0.
3. `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex` — exit 0.

All three TeX logs contain zero undefined citations, references, or control sequences. Captured command output and TeX logs are included in this packet. Minor non-fatal typesetting/hyperref warnings remain; the supplement reports an empty bibliography environment.

## Artifacts

| PDF | Pages | Bytes | SHA-256 | TeX log SHA-256 | Build-output log SHA-256 |
| --- | ---: | ---: | --- | --- | --- |
| `human_readable_main.pdf` | 34 | 833207 | `8bf003db76ca308786d848b98f171b11b697a7b21efea920e659b20d0519962d` | `b12a67d3d97f03d4076d789b7883db0c1ac13c7e3ced89b893a3f0575120f04d` | `68995065b7fdb1bf4c844988190d940991093c259bf7fce1dbbfc67d2f0db60c` |
| `lean_proof_details.pdf` | 11 | 406579 | `e41058299ce6bae2dea20acc2d1ca00e92a1af13842512280dc84c37e60d8c98` | `482ac62c055c7ce5d1638e4fccab6d18721a8b81386f8d03a81ba359aff3c028` | `833d8b673236c2ce71081667f53bb0a76553bbcfe73dd49450748b148996cc2a` |
| `main.pdf` | 34 | 833207 | `3f75f098de2fb5fdc92a595fc6c38d2bdca10cf595575f9c550c64595bf9d730` | `a923dd81f1dd4881f63ee0f1d96ab33fcc77b1f9b198f6c6c3c926526240e42d` | `1b03e2769af16669a5b7017594b80482cba6e9f36b801858efed1cc4427b4909` |

The old P3 review receipt and packet remain unchanged. This P4/S4 packet is a separate build result.
