from pathlib import Path
import tempfile,subprocess,hashlib,re,json
s=Path('/tmp/cluster-final-cache-layout-resume3-20261003.sh').read_text()
for tag,body in re.findall(r"<<'([A-Z][A-Z0-9]*)'\n(.*?)\n\1",s,re.S):compile(body,'driver:'+tag,'exec')
body=s.split("<<'PYMOVE'\n",1)[1].split('\nPYMOVE',1)[0]
with tempfile.TemporaryDirectory() as t:
 r=Path(t);old=r/'final-source/.lake';new=r/'final-source-guard-repaired/.lake';old.mkdir(parents=True);new.parent.mkdir()
 (old/'build').mkdir();(old/'packages/pkg').mkdir(parents=True);(old/'build/oracle').write_bytes(b'preserved cache bytes');new.symlink_to(old,target_is_directory=True)
 receipt=r/'receipt';receipt.mkdir();identity=(old.stat().st_dev,old.stat().st_ino)
 script=body.replace('(46,10611031912501232925)',repr(identity))
 subprocess.run(['python3','-',str(r),str(receipt)],input=script,text=True,check=True)
 assert new.is_dir() and not new.is_symlink() and old.is_symlink()
 assert (new.stat().st_dev,new.stat().st_ino)==identity
 assert (old/'build/oracle').read_bytes()==(new/'build/oracle').read_bytes()==b'preserved cache bytes'
 assert json.loads((receipt/'cache-relocation.json').read_text())['steps'][-1]=='real mount destination and contained package/build roots verified'
with tempfile.TemporaryDirectory() as t:
 r=Path(t);old=r/'final-source/.lake';old.mkdir(parents=True);new=r/'final-source-guard-repaired/.lake';new.parent.mkdir();wrong=r/'wrong';wrong.mkdir();new.symlink_to(wrong,target_is_directory=True);receipt=r/'receipt';receipt.mkdir()
 script=body.replace('(46,10611031912501232925)',repr((old.stat().st_dev,old.stat().st_ino)))
 p=subprocess.run(['python3','-',str(r),str(receipt)],input=script,text=True,capture_output=True)
 assert p.returncode!=0 and old.is_dir() and not old.is_symlink() and new.resolve()==wrong and not list(receipt.iterdir())
print('PASS independent relocation oracle: original inode/content preserved, destination real, old access preserved; wrong donor rejected before mutation.')
