# Independent review: C2 remaining-stage cache-layout resume

Verdict: PASS for the bounded remaining-stage resume, subject to its embedded checks and the existing outer guard. No Lean, verifier, comparator, or cluster job was run during this review.

Frozen candidate: `/tmp/cluster-final-cache-layout-resume3-20261003.sh`
SHA-256: `6fa1ae519128afcbae5253ae3666ae498876ec3f406cb82751b68c383644b85d`
Accepted base: `/tmp/cluster-final-retained-library-resume2-20261003.sh`
SHA-256: `e462d482bacf03dd908435e804e72c3e48e81ec02d02e7555b35159d3ba9b8b4`

The frozen delta binds the exact drained job 3136492 comparator-main exit 1, its recorded bwrap symlink-destination diagnostic and log digest, all three retained-module success records, both successful I/O probes, unchanged C2 source manifest, and absence of the other three comparator receipts. It independently requires the inherited job 3131801 full-verifier exit 0 and exact log digest. The prior outer guard must have finished without stop cause/live children and within the 21,600-second, two-CPU, 8-GiB limits. Fresh receipt paths prevent overwriting either earlier attempt.

The sole cache mutation is tightly bounded: checks that `.lake` is the exact symlink to the real contained donor, fixed device/inode identity, clean tracked source, and package pins precede mutation. It removes only that validated link, renames the donor directory on the same filesystem (no copy), checks the same inode at the real destination, recreates the donor path as a backlink, and verifies all package/build roots and package HEADs. On rename failure it restores the old target symlink. If a later journal/check fails after rename, the cache remains intact at the project destination; receipts identify the last completed operation. Source-manifest checks before relocation, immediately after relocation, and after comparisons guard tracked bytes/modes and cleanliness.

The defect mechanism matches the pinned Lean 4.35.0-rc3 Lake source: `src/lake/Lake/CLI/Check.lean` computes `dotLakeDir := projectDir / ".lake"` and passes that same path as the writable sandbox destination (`writablePaths := #[dotLakeDir]`, lines 255–267). Bubblewrap rejects a symlink at that mount destination, matching the retained failure log. Pinned source: https://github.com/leanprover/lean4/blob/470d5ce1400764999581fd26d5d72b00d990b0f4/src/lake/Lake/CLI/Check.lean

Only the four original comparator commands and final source/pin/guard checks remain. The driver does not repeat the successful verifier, retained module builds, or probes, and weakens no source, tool, trust, timeout, or resource gate. `bash -n` passed. The worker-local rename oracle was reported PASS by the controller; this review did not rerun it.
