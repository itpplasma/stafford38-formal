# Paper PDF compilation receipt — third input snapshot

Status: all three PDF builds exited 0 using five TeX/bibliography source inputs and the README build instructions from the isolated P3 copy. The P3 license file was added to the evidence packet after compilation and was not a build input. This receipt records paper compilation, not Lean verification or paper-to-Lean correspondence acceptance.

## Frozen source identity

- Paper checkout: `/home/ert/proj/stafford38-paper`
- Paper origin commit P3: `a5a703f588ef3a2c43e8fc21f89db8bf494af5db`
- Controller snapshot label S3: `22b44d56af302bbf8dd3542316d8b15a2b0c5315`
- Formal commit linked by `ai_review.tex` (C2): `12ae3cc49152672a48a96f13994314b65ae38197`
- AlgebraicAnalysis pin: `bbbbf3fc358ca8100b158cec4cf47f336ab70163` (v0.3.3)
- `human_readable_main.tex` SHA-256: `48f6b8132426f0378d2d1b7f79598cc87a693ab00f1daae8a16760d3b39dc2c4`; unchanged from the prior approved mathematical-paper input.
- `ai_review.tex` is the only changed paper source since its prior input: the formal repository link now points to C2; the proof text source hash above is unchanged.
- The local paper worktree was clean before compilation. All copies and generated output are under this directory; no paper repository source was edited.

## Five TeX/bibliography inputs used to compile

| Input | SHA-256 |
| --- | --- |
| `ai_review.tex` | `7b63c12e75b713e2c72506777274502df18ae397408ce0475f3225a7d63a492b` |
| `human_readable_main.tex` | `48f6b8132426f0378d2d1b7f79598cc87a693ab00f1daae8a16760d3b39dc2c4` |
| `lean_proof_details.tex` | `fb8b61d1570ade614cdb451f1a93544c09f1d2abeac6ba7a254b8d7bf5cc982a` |
| `main.tex` | `b55ef1f254b7611b37b4bdf7633991400cdb4512bd03e0532d1f90f561cf7cbe` |
| `references.bib` | `22a4e3e4e4e7f806abd39eb22bb6405887e280a7fc75e661f69585529010c4f0` |

The five build-source hashes above and copied `README.md` build instructions were recorded in the initial six-file before/after manifests (`inputs-before.sha256` and `inputs-after.sha256`; both manifest-file SHA-256 `0930bcc9258dbe4f2d12a21ff149d898981c132f575169fd84d4152279172b6e`). The manifests match byte-for-byte. `README.md` SHA-256 is `ce5d79c55cf748753dda1b3172230b631ee50aade650e250eac60ae7b320ae49`. After compilation, P3 `LICENSE.txt` was added solely for the source packet; SHA-256 `98b6fde2693d4044dce4a071640e90bd8d250dd789d9033dbd5b77c79f389de4`. It is excluded from those before/after build-input manifests.

## Toolchain and commands

- `latexmk`: 4.87 (15 June 2025)
- `pdfTeX`: 3.141592653-2.6-1.40.29 (TeX Live 2026/Arch Linux)
- Build commands, in README order, all with `-interaction=nonstopmode -halt-on-error`:
  1. `latexmk -pdf -interaction=nonstopmode -halt-on-error human_readable_main.tex` — exit 0.
  2. `latexmk -pdf -interaction=nonstopmode -halt-on-error lean_proof_details.tex` — exit 0.
  3. `latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex` — exit 0.
- Captured command logs: `human_readable_main.build.log`, `lean_proof_details.build.log`, `main.build.log`.
- TeX logs contain zero undefined citations, references, or control sequences in all three builds.

## Artifacts

| PDF | Pages | Bytes | SHA-256 | TeX log SHA-256 | Build-output log SHA-256 |
| --- | ---: | ---: | --- | --- | --- |
| `human_readable_main.pdf` | 34 | 832596 | `d00c12d63d4f77e0eeaf2226579a11cddc078d5134464b024312160438f90429` | `7223f7d62da47de914954be4c4a50fb7494fa6d81872d35c08695f08e0763091` | `173e7577d69eb7295b7e86fa33b0836366c05364be89182da541d282c2e30ad0` |
| `lean_proof_details.pdf` | 11 | 406579 | `e984e778629569c9f7074cbacb36d995b275145999dfbba16c892841633fbe55` | `3afee1be72f4c7938a683f599d565ad11b8c4523c8ed1939877bb8a2eaea9718` | `833d8b673236c2ce71081667f53bb0a76553bbcfe73dd49450748b148996cc2a` |
| `main.pdf` | 34 | 832596 | `bcda47dfd4e0a7aad0034808cd73c026e70eb7e181fa505edf73a09efcab27a6` | `3d4506b8df519d80273684918ec847e61194c5778c36260bbcf51b17c5e91848` | `60fe9cfb6a1abc4323c6d96293a92b249c0601d2abc46403fe33ad44b3bec305` |

Non-fatal typesetting notes remain: overfull/underfull boxes and three hyperref PDF-string warnings in the manuscript/main logs; the supplement reports an empty bibliography environment. These logs have no undefined citations, references, or control sequences.
