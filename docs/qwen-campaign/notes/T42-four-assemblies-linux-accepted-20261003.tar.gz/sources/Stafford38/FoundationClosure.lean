module
public import Stafford38.Characteristic.CanonicalKoszulContradiction
public import Stafford38.Characteristic.CanonicalGabberInvolutivityInterface
public import Stafford38.Geometry.ExactDivisorialVisibleFrameExistence
public import Stafford38.PaperInputs
public import Stafford38.Geometry.GeneralCoisotropicCanonicalAdapter
public import Stafford38.Weyl.PaperQuotientDescent

@[expose] public section

/-! The paper's three assembly interfaces and both universal statements are
proved from Lean and Mathlib without project or literature axioms. The final
canonical-support proof uses the general coisotropic-set theorem.

## References and proof context

[Sta78] J. T. Stafford, *Module Structure of Weyl Algebras*, Journal of the London Mathematical Society (2) 18 (1978), 429–442.
https://doi.org/10.1112/jlms/s2-18.3.429

Conjecture 3.8, p. 438, is the source problem. This project proves the general case and exact-degree strengthening. See docs/literature.md for the imported involutivity and visible-frame route.
-/

namespace Stafford38.FoundationClosure

universe u

theorem canonicalNoncharacteristicSupportAvoidance :
    PaperInputs.CanonicalNoncharacteristicSupportAvoidance.{u} := by
  intro k _ _ _ n N d hN hd
  exact Characteristic.CanonicalKoszulContradiction.canonical_support_avoidance
    k n N d hN hd

def inputs : PaperInputs.Inputs.{u} where
  noncharacteristicApplication := canonicalNoncharacteristicSupportAvoidance
  residueExtensionSymbolControl :=
    Characteristic.CanonicalGabberInvolutivityInterface.canonicalResidueExtensionSymbolControl_of_associatedGradedRadical
      Characteristic.GabberGlobalAssembly.weylAssociatedGradedRadicalInvolutivity
  higherDimensionalVisibleDivisorFrameProduction :=
    Geometry.ExactDivisorialVisibleFrameExistence.higherDimensionalCanonicalVisibleDivisorFrameProduction

theorem canonicalSupportVanishingViaGeneralCoisotropic :
    UniversalAssembly.CanonicalSupportVanishing.{u} := by
  let hunit : CanonicalSupportVanishingReduction.CanonicalStrictUnitCoordinatePreimage.{u} := by
    intro k _ _ _ n N d hN hd
    exact SpecializedNoncharacteristicEquality.strictUnitCoordinatePreimage_of_transposedSupport_disjoint_axis
      k n N d (canonicalNoncharacteristicSupportAvoidance k n N d hN hd)
  exact Stafford38.PaperQuotientDescent.canonicalSupportDescent_via_quotient
    (Geometry.GeneralCoisotropicCanonicalAdapter.algebraicallyClosedCanonicalSupportVanishing_of_generalCoisotropic
      hunit)

theorem canonicalSupportVanishingViaGenericLaurent :
    UniversalAssembly.CanonicalSupportVanishing.{u} := by
  let hunit : CanonicalSupportVanishingReduction.CanonicalStrictUnitCoordinatePreimage.{u} := by
    intro k _ _ _ n N d hN hd
    exact SpecializedNoncharacteristicEquality.strictUnitCoordinatePreimage_of_transposedSupport_disjoint_axis
      k n N d (canonicalNoncharacteristicSupportAvoidance k n N d hN hd)
  exact Stafford38.PaperQuotientDescent.canonicalSupportDescent_via_quotient
    (Geometry.GeneralCoisotropicCanonicalAdapter.algebraicallyClosedCanonicalSupportVanishing_genericLaurent
      hunit)

end Stafford38.FoundationClosure

namespace Stafford38

universe u

theorem universalStatement : UniversalStatement.{u} :=
  UniversalAssembly.universalStatement_of_canonicalSupportVanishing
    FoundationClosure.canonicalSupportVanishingViaGeneralCoisotropic

theorem universalFixedSourceStatement : FixedSource.UniversalFixedSourceStatement.{u} :=
  FixedSource.universalFixedSourceStatement_of_canonicalSupportVanishing
    FoundationClosure.canonicalSupportVanishingViaGeneralCoisotropic

#print axioms universalStatement
#print axioms universalFixedSourceStatement

end Stafford38

namespace Stafford38.GenericLaurentVariant

universe u

/-- Challenge theorem assembled through the historical generic/Laurent route. -/
theorem universalStatement : UniversalStatement.{u} :=
  UniversalAssembly.universalStatement_of_canonicalSupportVanishing
    FoundationClosure.canonicalSupportVanishingViaGenericLaurent

/-- Fixed-source strengthening assembled through the same historical route. -/
theorem universalFixedSourceStatement : FixedSource.UniversalFixedSourceStatement.{u} :=
  FixedSource.universalFixedSourceStatement_of_canonicalSupportVanishing
    FoundationClosure.canonicalSupportVanishingViaGenericLaurent

#print axioms universalStatement
#print axioms universalFixedSourceStatement

end Stafford38.GenericLaurentVariant
