import argparse, importlib.util, json, os, signal, subprocess, sys, tempfile, time
from pathlib import Path
ROOT=Path.cwd(); SCR=ROOT/'.lake/campaign-resource-scratch'
spec=importlib.util.spec_from_file_location('guard',ROOT/'docs/qwen-campaign/linux-guard.py')
g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
def setup():
 g.snapshot=lambda: {'mem_total_bytes':96*g.GIB,'mem_available_bytes':80*g.GIB,'swap_used_bytes':14*g.GIB,'psi':{'some':0.,'full':0.}}
 g.disk_sample=lambda paths: (600*g.GIB,{str(p):600*g.GIB for p in paths})
def args(d,source,timeout=3):
 return argparse.Namespace(command=[sys.executable,'-c',source],cwd=str(ROOT),timeout=timeout,log=str(d/'nested/run.log'))
if len(sys.argv)>1:
 setup();d=Path(sys.argv[2]); source=sys.argv[3]
 if sys.argv[1]=='rss':
  real=g.group
  def high(p):
   rss,live=real(p);return (9*g.GIB if live else rss),live
  g.group=high
 sys.exit(g.run(args(d,source)))
setup()
d=Path(tempfile.mkdtemp(prefix='sol-',dir=SCR))
# Independent child asserts actual affinity and environment.
a=args(d,"import os; assert len(os.sched_getaffinity(0))==2; assert os.getenv('LEAN_NUM_THREADS')=='2'")
assert g.run(a)==0
assert json.loads((d/'nested/run.json').read_text())['guard_exit_code']==0
# Foreign-process refusal uses safe controlled comm naming (no Lean executable).
f=subprocess.Popen([sys.executable,'-c',"import ctypes,time;ctypes.CDLL(None).prctl(15,b'lean',0,0,0);time.sleep(20)"])
try:
 time.sleep(.2);assert f.pid in g.foreign_lean();assert g.check()==96;assert g.run(a)==96;assert f.poll() is None
finally:f.terminate();f.wait()
# Parent exits while child continues: slot must remain occupied until timeout.
for mode in ('descendant','signal','interrupt','rss'):
 case=d/mode;case.mkdir()
 source="import subprocess,time;subprocess.Popen(['sleep','20']);"+('time.sleep(20)' if mode!='descendant' else '')
 p=subprocess.Popen([sys.executable,__file__,'rss' if mode=='rss' else 'normal',str(case),source])
 time.sleep(.6)
 if mode!='rss':
  assert g.check()==96
 if mode in ('signal','interrupt'):p.send_signal(signal.SIGTERM if mode=='signal' else signal.SIGINT)
 rc=p.wait(timeout=8);rec=json.loads((case/'nested/run.json').read_text())
 assert rc==({'descendant':93,'signal':143,'interrupt':130,'rss':91}[mode]),(mode,rc,rec)
 assert rec['guard_exit_code']==rc and not rec['live_child_pids_at_exit']
 assert g.acquire_slot() is not None
 print(mode,rc,rec['reason'])
print('PASS affinity, foreign refusal/preservation, descendant lock, signal cleanup, timeout, simulated production RSS boundary')
