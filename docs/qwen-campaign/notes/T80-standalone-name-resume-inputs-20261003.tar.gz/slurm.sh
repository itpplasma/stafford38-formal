#!/usr/bin/env bash
#SBATCH --partition=compute
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=2
#SBATCH --mem=8G
#SBATCH --time=01:00:00
#SBATCH --nodelist=node20
#SBATCH --output=/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/T80-C2-after-final-resume1-20261003.slurm
set -euo pipefail
export STAFFORD_RUN_ROOT=/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815
export EXPECTED_FORMAL_PIN=12ae3cc49152672a48a96f13994314b65ae38197
export FINAL_SOURCE_ROOT="$STAFFORD_RUN_ROOT/final-source-guard-repaired"
export T80_ROOT="$STAFFORD_RUN_ROOT/control/T80-C2-resume1"
export T80_RECEIPTS="$STAFFORD_RUN_ROOT/T80-C2-after-final-resume1-20261003-receipts"
test ! -e "$T80_RECEIPTS"
test "$(sha256sum "$T80_ROOT/run-T80-C2.sh" | cut -d ' ' -f1)" = b34c8fe29f0af2abbfd3fc3803f9015442448a6daafbb9462aead65d016d20e7
test "$(sha256sum "$T80_ROOT/manifest.json" | cut -d ' ' -f1)" = b5ce49dd14ae1c7f1f38804449570608cef3285703e6952cbb3445bdc669dba2
# Resume only the actual failed name-check job after its guard has drained.
python3 - "$STAFFORD_RUN_ROOT" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1]);g=json.loads((r/'logs/T80-C2-after-final-20261003-outer.json').read_text())
assert str(g['slurm_job_id'])=='3138990'
assert g['guard_exit_code']==g['command_exit_code']==1 and g['reason']=='finished'
assert not g['live_child_pids_at_exit'] and not g['stop_cause']
assert g['peak_swap_growth_bytes']==0
assert g['rss_cap_bytes']==8589934592 and g['threads']==2 and g['timeout_seconds']==3300
assert g['peak_rss_bytes']<=g['rss_cap_bytes']
PY
# Final public replay must actually PASS and be drained before this separate check.
python3 - "$STAFFORD_RUN_ROOT" <<'PY'
import json,sys
from pathlib import Path
r=Path(sys.argv[1])
t=json.loads((r/'final-receipts-guard-repaired-resume4/terminal.json').read_text())
g=json.loads((r/'final-C2-resume4-outer-guard.json').read_text())
assert t['exit_status']==0 and t['failed_or_last_stage']=='complete'
assert t['source_commit']=='12ae3cc49152672a48a96f13994314b65ae38197'
assert g['guard_exit_code']==g['command_exit_code']==0 and g['reason']=='finished'
assert not g['live_child_pids_at_exit'] and not g['stop_cause']
PY
srun --ntasks=1 --cpus-per-task=2 --cpu-bind=cores python3 "$STAFFORD_RUN_ROOT/linux-slurm-guard.py" run --timeout 3300 --log "$STAFFORD_RUN_ROOT/logs/T80-C2-after-final-resume1-20261003-outer.log" --cwd "$FINAL_SOURCE_ROOT" -- bash "$T80_ROOT/run-T80-C2.sh"
