#!/bin/bash
set -euo pipefail
stafford_run="${STAFFORD_RUN_ROOT:?set approved Linux run root}"
EXPECTED_FORMAL_PIN=12ae3cc49152672a48a96f13994314b65ae38197
: "${FINAL_SOURCE_ROOT:?set clean immutable C2 clone path}"
: "${T80_ROOT:?set C2 T80 input directory}"
: "${T80_RECEIPTS:?set unique C2 T80 receipt directory}"
export ELAN_HOME="$stafford_run/elan"
export ELAN_TOOLCHAIN=leanprover/lean4:v4.35.0-rc3
export PATH="$stafford_run/bootstrap/bin:$stafford_run/bootstrap/curl-runtime:$ELAN_HOME/toolchains/leanprover--lean4---v4.35.0-rc3/bin:$ELAN_HOME/bin:$stafford_run/bootstrap:$PATH"
cd "$FINAL_SOURCE_ROOT"
test "$(git rev-parse HEAD)" = "$EXPECTED_FORMAL_PIN"
test -z "$(git status --porcelain=v1 --untracked-files=all)"
test "$(lean --githash)" = 470d5ce1400764999581fd26d5d72b00d990b0f4
test "$(sha256sum lake-manifest.json | cut -d ' ' -f1)" = 29658324d2c247fb161a35c9869ac7e3c43491614304343a81337c65fae5dcbc
python3 - <<'PY'
from pathlib import Path
import hashlib,json,subprocess
import os
root=Path(os.environ['T80_ROOT'])
m=json.loads((root/'manifest.json').read_text())
assert m['formal_public_pin']==os.environ['EXPECTED_FORMAL_PIN']==subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
for p in json.loads(Path('lake-manifest.json').read_text())['packages']:
 assert subprocess.check_output(['git','-C','.lake/packages/'+p['name'],'rev-parse','HEAD'],text=True).strip()==p['rev']
for g in m['groups'].values():
 assert hashlib.sha256((root/g['file']).read_bytes()).hexdigest()==g['sha256']
 for t in g.get('standalone_sources',[]):
  assert hashlib.sha256((root/t['tail_file']).read_bytes()).hexdigest()==t['tail_sha256']
  raw=Path(t['owner']).read_bytes()
  assert raw==subprocess.check_output(['git','show',m['formal_public_pin']+':'+t['owner']])
  assert hashlib.sha256(raw).hexdigest()==t['source_sha256']
out=Path(os.environ['T80_RECEIPTS'])
out.mkdir(exist_ok=False)
results=[]
def compile_check(name, path, checks, source_hash, record, owner=None):
 log=out/(name+'.log')
 with log.open('w') as f:
  r=subprocess.run(['lake','env','lean','--trust=0','-M8000',str(path)],stdout=f,stderr=subprocess.STDOUT)
 (out/(name+'.exit')).write_text(str(r.returncode)+'\n')
 evidence={'owner':owner,'exit':r.returncode,'checks':checks,'source_sha256':source_hash,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'log':log.name}
 record['parts'].append(evidence)
 record['completed_checks']+=checks if r.returncode==0 else 0
 record['exit']=r.returncode if r.returncode or record['completed_checks']==record['checks'] else None
 if owner is None:
  record['source_sha256']=source_hash
  record['log_sha256']=evidence['log_sha256']
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,'exit',r.returncode,'checks',checks,flush=True)
 if r.returncode:
  print('\n'.join(x for x in log.read_text().splitlines() if 'error:' in x)[:2500],flush=True)
  raise SystemExit(r.returncode)
for name,g in m['groups'].items():
 record={'group':name,'exit':None,'checks':g['public_checks'],'completed_checks':0,'parts':[]}
 results.append(record)
 compile_check(name,root/g['file'],g.get('imported_public_checks',g['public_checks']),g['sha256'],record)
 for t in g.get('standalone_sources',[]):
  raw=Path(t['owner']).read_bytes()
  # Preserve every source byte and declaration; add only a qualified name query.
  combined=raw+(root/t['tail_file']).read_bytes()
  scratch=out/t['owner']
  scratch.parent.mkdir(parents=True,exist_ok=True)
  scratch.write_bytes(combined)
  compile_check(name+'-'+Path(t['owner']).stem,scratch,t['public_checks'],hashlib.sha256(combined).hexdigest(),record,t['owner'])
assert all(x['exit']==0 and x['completed_checks']==x['checks'] for x in results)
assert sum(x['checks'] for x in results)==m['package_public_checks_excluding_global']==399
print('FOUR_ISOLATED_T80_GROUPS_PASS',flush=True)
PY
test -z "$(git status --porcelain=v1 --untracked-files=all)"
