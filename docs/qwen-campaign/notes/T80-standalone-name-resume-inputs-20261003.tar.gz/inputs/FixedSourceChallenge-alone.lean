-- Scratch T80 compiler-acceptance source; deliberately not executed by the preparer.
-- All public declarations below are resolved to this file and line in the candidate locator audit.
import FixedSourceChallenge

-- formal:FixedSourceChallenge.lean:157
#check Stafford38FixedSourceChallenge.bernsteinDegree
-- formal:FixedSourceChallenge.lean:195
#check Stafford38FixedSourceChallenge.UniversalFixedSourceStatement
