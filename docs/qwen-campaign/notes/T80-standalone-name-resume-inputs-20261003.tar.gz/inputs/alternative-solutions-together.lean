-- Scratch T80 compiler-acceptance source; deliberately not executed by the preparer.
-- All public declarations below are resolved to this file and line in the candidate locator audit.
import AlternativeFixedSourceSolution
import AlternativeSolution

-- formal:AlternativeFixedSourceSolution.lean:20
#check Stafford38FixedSourceChallenge.universalFixedSourceStatement
-- formal:AlternativeSolution.lean:17
#check Stafford38Challenge.universalStatement
