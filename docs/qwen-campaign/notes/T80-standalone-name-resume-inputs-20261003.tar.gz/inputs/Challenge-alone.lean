-- Scratch T80 compiler-acceptance source; deliberately not executed by the preparer.
-- All public declarations below are resolved to this file and line in the candidate locator audit.
import Challenge

-- formal:Challenge.lean:85
#check Stafford38Challenge.relation
-- formal:Challenge.lean:95
#check Stafford38Challenge.UniversalStatement
