# T80 C2/P3/S3 compiler-name-check runner

This is the no-launch controller runner, using the four existing, source-hashed T80 `#check` groups. The expected public formal pin is fixed to `12ae3cc49152672a48a96f13994314b65ae38197`; the input manifest also pins P3/S3 (`a5a703f588ef3a2c43e8fc21f89db8bf494af5db` / `22b44d56af302bbf8dd3542316d8b15a2b0c5315`) and map SHA recorded there.

Only when the controller elects to run it inside the approved guarded Linux allocation after the final verifier has completed successfully, set `STAFFORD_RUN_ROOT` to the fresh isolated run root with pinned elan/curl bootstrap, `FINAL_SOURCE_ROOT` to the clean immutable C2 clone, and `T80_RECEIPTS` to a new nonexistent receipt directory. Set `T80_ROOT` to this directory, then run `bash "$T80_ROOT/run-T80-C2.sh"`. The script reuses the clone's built Lake cache, checks the exact Lean toolchain, lake manifest and all package HEADs, then runs the four independent groups in order and stops on the first compiler failure. It records each group exit and log hash. Do not launch from a login shell.

Groups are unchanged from the accepted map candidate: 393 common/main/library/mathlib checks; `Challenge` alone (2); `FixedSourceChallenge` alone (2); and both alternative roots together (2). Global archived refs (2) and 11 private helpers stay source-only. No Lean execution is included in this preparation.
