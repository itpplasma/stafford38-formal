import Stafford38.Geometry.ActualSameWitnessGroundPointCompletion
import Stafford38.Geometry.ActualOptionColumnBinding
import Stafford38.Geometry.ActualSelectedNormalizationAway
import Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualWitnessCommonOpenColumnGlue
import Stafford38.Geometry.ActualWitnessSelectedChartBinding
import Stafford38.Geometry.ActualSelectedNormalizationChartTransport
import Stafford38.Geometry.ChartGenericPointFractionRing
import Stafford38.Geometry.ActualOptionCommonOpenColumns
import Stafford38.Geometry.ActualPointCommonOpenAssembly
import Stafford38.Geometry.ActualOptionGroundPointCompletion
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualSameWitnessAffineFibreEndpoint
import Stafford38.Geometry.ActualWitnessSelectedChartIndex
import Stafford38.Geometry.A0NormalizedProjectiveCoordinates
import Stafford38.Geometry.ActualSmoothOpenChartNumerator
import Stafford38.Geometry.CommonOpenEvaluation
import Stafford38.Geometry.ActualCommonOpenArcCompatibility
import Stafford38.Geometry.ProjectiveChartSameFieldOverlap
import Stafford38.Geometry.AsymptoticChartArcAdapter
import Stafford38.Geometry.A0ChartFormalEtale
import Stafford38.Geometry.A0ChartGeneratorCoordinates

set_option autoImplicit false
noncomputable section
open Stafford38.Geometry.ComponentProjectiveClosure
open Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
open Stafford38.Geometry.GeneralDivisorialVisibleFrame
open Stafford38.Geometry.EtaleGenericOpenTransport
open Stafford38.Geometry.ComponentFunctionFieldBoundary
open Stafford38.Geometry.AsymptoticDivisorExistence
open Stafford38.Geometry.RelativeCoefficientDVR
open IsLocalRing
universe u
variable {k : Type u} [Field k] [CharZero k] [IsAlgClosed k]
  {m d : ℕ} (hm : 0 < m)
  (P : PrimeSpectrum (MvPolynomial (Fin m) k))
  (w : GeneralDivisorialVisibleFrameWitness hm P)
local instance : Algebra k (actualSelectedNormalization P w) := (actualSelectedNormalizationCoefficients P w).toAlgebra
variable (M : Ideal (actualSelectedNormalization P w)) [M.IsPrime]
  (f g : (actualSelectedChartAlgebra P w))
  (e : Localization.Away f ≃ₐ[(actualSelectedChartAlgebra P w)]
    Localization.Away (algebraMap (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w) f))
-- after coefficient installation, before explicit tower k/Q/B
#synth IsScalarTower k (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w)
-- before R/B installation
#synth Algebra (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w)
variable [rB : Algebra (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w)]
-- before tower k/R/B installation
#synth IsScalarTower k (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w)
-- before R/Cq installation
#synth Algebra (MvPolynomial (Option (Fin d)) k) (genericOpenRing M f e)
-- before R/U installation
#synth Algebra (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- before etale R/atPrime certificate
#synth Algebra.FormallyEtale (MvPolynomial (Option (Fin d)) k) (Localization.AtPrime M)
variable [kRB : IsScalarTower k (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w)]
local instance : Algebra (MvPolynomial (Option (Fin d)) k) (genericOpenRing M f e) := ((algebraMap (actualSelectedNormalization P w) (genericOpenRing M f e)).comp (algebraMap (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w))).toAlgebra
-- after R/Cq, before explicit R/U
#synth Algebra (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- after R/Cq, before explicit k/R/U
#synth IsScalarTower k (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- after R/Cq, before etale R/U
#synth Algebra.FormallyEtale (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- R/U derived SMul
#synth SMul (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- k/U derived SMul
#synth SMul k (genericOpenExtraAwayB M f e g)

-- raw B domain (archived line116)
#synth IsDomain (actualSelectedNormalization P w)
-- before finite-type witness certificate (line174)
#synth Algebra.FiniteType k (actualSelectedNormalization P w)
-- before essential-finite-type proof (line210)
#synth Algebra.EssFiniteType (MvPolynomial (Option (Fin d)) k) (actualSelectedNormalization P w)
