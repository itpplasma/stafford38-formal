import Stafford38.Geometry.ActualSameWitnessGroundPointCompletion
import Stafford38.Geometry.ActualOptionColumnBinding
import Stafford38.Geometry.ActualSelectedNormalizationAway
import Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualWitnessCommonOpenColumnGlue
import Stafford38.Geometry.ActualWitnessSelectedChartBinding
import Stafford38.Geometry.ActualSelectedNormalizationChartTransport
import Stafford38.Geometry.ChartGenericPointFractionRing
import Stafford38.Geometry.ActualOptionCommonOpenColumns
import Stafford38.Geometry.ActualPointCommonOpenAssembly
import Stafford38.Geometry.ActualOptionGroundPointCompletion
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualSameWitnessAffineFibreEndpoint
import Stafford38.Geometry.ActualWitnessSelectedChartIndex
import Stafford38.Geometry.A0NormalizedProjectiveCoordinates
import Stafford38.Geometry.ActualSmoothOpenChartNumerator
import Stafford38.Geometry.CommonOpenEvaluation
import Stafford38.Geometry.ActualCommonOpenArcCompatibility
import Stafford38.Geometry.ProjectiveChartSameFieldOverlap
import Stafford38.Geometry.AsymptoticChartArcAdapter
import Stafford38.Geometry.A0ChartFormalEtale
import Stafford38.Geometry.A0ChartGeneratorCoordinates

set_option autoImplicit false
noncomputable section
open Stafford38.Geometry.ComponentProjectiveClosure
open Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
open Stafford38.Geometry.GeneralDivisorialVisibleFrame
open Stafford38.Geometry.EtaleGenericOpenTransport
open Stafford38.Geometry.ComponentFunctionFieldBoundary
open Stafford38.Geometry.AsymptoticDivisorExistence
open Stafford38.Geometry.RelativeCoefficientDVR
open IsLocalRing
universe u
variable {k : Type u} [Field k] [CharZero k] [IsAlgClosed k]
  {m d : ℕ} (hm : 0 < m)
  (P : PrimeSpectrum (MvPolynomial (Fin m) k))
  (w : GeneralDivisorialVisibleFrameWitness hm P)
-- raw F/k
#synth Algebra k (ComponentFractionField P)
-- raw F/local coefficient
#synth Algebra (CoordinateZeroLocalRing w.column.W.coefficientField) (ComponentFractionField P)
-- raw F/Q
#synth Algebra (actualSelectedChartAlgebra P w) (ComponentFractionField P)
-- raw Q/k
#synth Algebra k (actualSelectedChartAlgebra P w)
-- raw B/Q
#synth Algebra (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w)
-- raw B/k
#synth Algebra k (actualSelectedNormalization P w)
-- raw B tower k/Q/B
#synth IsScalarTower k (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w)
-- raw R/k
#synth Algebra k (MvPolynomial (Option (Fin d)) k)
-- raw A0/k
#synth Algebra k (MvPolynomial (Fin m) k ⧸ P.asIdeal)
-- raw A0/poly
#synth Algebra (MvPolynomial (Fin m) k) (MvPolynomial (Fin m) k ⧸ P.asIdeal)
local instance : Algebra (CoordinateZeroLocalRing w.column.W.coefficientField) (ComponentFractionField P) := w.column.W.ambientAlgebra
-- ambient installed V/k
#synth Algebra k (w.column.W.place.valuation.toSubring)
-- ambient installed V/coefficient
#synth Algebra w.column.W.coefficientField (w.column.W.place.valuation.toSubring)
-- ambient installed V/DVR
#synth IsDiscreteValuationRing (w.column.W.place.valuation.toSubring)
local instance : IsDiscreteValuationRing (w.column.W.place.valuation.toSubring) := w.column.W.place.isDiscrete
-- DVR installed V/local
#synth IsLocalRing (w.column.W.place.valuation.toSubring)
-- DVR installed residue/V
#synth Algebra (w.column.W.place.valuation.toSubring) (ResidueField (w.column.W.place.valuation.toSubring))
-- DVR installed residue/k
#synth Algebra k (ResidueField (w.column.W.place.valuation.toSubring))
-- DVR installed residue/coefficient
#synth Algebra w.column.W.coefficientField (ResidueField (w.column.W.place.valuation.toSubring))
local instance : Algebra w.column.W.coefficientField (w.column.W.place.valuation.toSubring) := (relativeCoefficientMap w.column.W.coefficientField w.column.W.place).toAlgebra
-- coefficient installed residue/coefficient
#synth Algebra w.column.W.coefficientField (ResidueField (w.column.W.place.valuation.toSubring))
-- coefficient installed residue/k
#synth Algebra k (ResidueField (w.column.W.place.valuation.toSubring))
