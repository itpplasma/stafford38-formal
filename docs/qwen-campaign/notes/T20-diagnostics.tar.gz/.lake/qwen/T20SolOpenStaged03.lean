import Stafford38.Geometry.ActualSameWitnessGroundPointCompletion
import Stafford38.Geometry.ActualOptionColumnBinding
import Stafford38.Geometry.ActualSelectedNormalizationAway
import Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualWitnessCommonOpenColumnGlue
import Stafford38.Geometry.ActualWitnessSelectedChartBinding
import Stafford38.Geometry.ActualSelectedNormalizationChartTransport
import Stafford38.Geometry.ChartGenericPointFractionRing
import Stafford38.Geometry.ActualOptionCommonOpenColumns
import Stafford38.Geometry.ActualPointCommonOpenAssembly
import Stafford38.Geometry.ActualOptionGroundPointCompletion
import Stafford38.Geometry.SameWitness.AxisLiftFromGroundPoint
import Stafford38.Geometry.ActualSameWitnessAffineFibreEndpoint
import Stafford38.Geometry.ActualWitnessSelectedChartIndex
import Stafford38.Geometry.A0NormalizedProjectiveCoordinates
import Stafford38.Geometry.ActualSmoothOpenChartNumerator
import Stafford38.Geometry.CommonOpenEvaluation
import Stafford38.Geometry.ActualCommonOpenArcCompatibility
import Stafford38.Geometry.ProjectiveChartSameFieldOverlap
import Stafford38.Geometry.AsymptoticChartArcAdapter
import Stafford38.Geometry.A0ChartFormalEtale
import Stafford38.Geometry.A0ChartGeneratorCoordinates

set_option autoImplicit false
noncomputable section
open Stafford38.Geometry.ComponentProjectiveClosure
open Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
open Stafford38.Geometry.GeneralDivisorialVisibleFrame
open Stafford38.Geometry.EtaleGenericOpenTransport
open Stafford38.Geometry.ComponentFunctionFieldBoundary
open Stafford38.Geometry.AsymptoticDivisorExistence
open Stafford38.Geometry.RelativeCoefficientDVR
open IsLocalRing
universe u
variable {k : Type u} [Field k] [CharZero k] [IsAlgClosed k]
  {m d : ℕ} (hm : 0 < m)
  (P : PrimeSpectrum (MvPolynomial (Fin m) k))
  (w : GeneralDivisorialVisibleFrameWitness hm P)
local instance : Algebra k (actualSelectedNormalization P w) := (actualSelectedNormalizationCoefficients P w).toAlgebra
local instance : IsScalarTower k (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w) := by
  apply IsScalarTower.of_algebraMap_eq
  intro c
  rfl
variable (M : Ideal (actualSelectedNormalization P w)) [M.IsPrime]
  (f g : (actualSelectedChartAlgebra P w))
  (e : Localization.Away f ≃ₐ[(actualSelectedChartAlgebra P w)]
    Localization.Away (algebraMap (actualSelectedChartAlgebra P w) (actualSelectedNormalization P w) f))
-- coefficient + k/Q/B tower installed: Cq/Q
#synth Algebra (actualSelectedChartAlgebra P w) (genericOpenRing M f e)
-- coefficient + k/Q/B tower installed: Cq/k
#synth Algebra k (genericOpenRing M f e)
-- coefficient + k/Q/B tower installed: Cq/B
#synth Algebra (actualSelectedNormalization P w) (genericOpenRing M f e)
-- coefficient + k/Q/B tower installed: U/Cq
#synth Algebra (genericOpenRing M f e) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: U/Q
#synth Algebra (actualSelectedChartAlgebra P w) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: U/k
#synth Algebra k (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: U/B
#synth Algebra (actualSelectedNormalization P w) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint A0/U
#synth Algebra (MvPolynomial (Fin m) k ⧸ P.asIdeal) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint poly/U
#synth Algebra (MvPolynomial (Fin m) k) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint R/U
#synth Algebra (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint k/A0/U
#synth IsScalarTower k (MvPolynomial (Fin m) k ⧸ P.asIdeal) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint k/poly/U
#synth IsScalarTower k (MvPolynomial (Fin m) k) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint k/R/U
#synth IsScalarTower k (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint poly/A0/U
#synth IsScalarTower (MvPolynomial (Fin m) k) (MvPolynomial (Fin m) k ⧸ P.asIdeal) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint etale A0/U
#synth Algebra.FormallyEtale (MvPolynomial (Fin m) k ⧸ P.asIdeal) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: endpoint etale R/U
#synth Algebra.FormallyEtale (MvPolynomial (Option (Fin d)) k) (genericOpenExtraAwayB M f e g)
-- coefficient + k/Q/B tower installed: tower k/Q/Cq
#synth IsScalarTower k (actualSelectedChartAlgebra P w) (genericOpenRing M f e)
-- coefficient + k/Q/B tower installed: tower k/Q/U
#synth IsScalarTower k (actualSelectedChartAlgebra P w) (genericOpenExtraAwayB M f e g)
