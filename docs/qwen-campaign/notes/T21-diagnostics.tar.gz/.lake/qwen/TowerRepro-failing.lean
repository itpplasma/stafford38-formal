import Mathlib.RingTheory.MvPolynomial.Basic
import Mathlib.RingTheory.Ideal.Quotient.Operations
import Mathlib.RingTheory.Localization.Away.Basic

variable {k : Type*} [Field k] {m : ℕ}
variable (P : Ideal (MvPolynomial (Fin m) k)) [P.IsPrime]

example : IsScalarTower k (MvPolynomial (Fin m) k)
    (MvPolynomial (Fin m) k ⧸ P) := inferInstance

example {E : Type*} [CommRing E] [Algebra k E]
    (φ : (MvPolynomial (Fin m) k ⧸ P) →ₐ[k] E) :
    letI := φ.toRingHom.toAlgebra
    IsScalarTower k (MvPolynomial (Fin m) k ⧸ P) E := by
  letI := φ.toRingHom.toAlgebra
  exact IsScalarTower.of_algebraMap_eq' φ.comp_algebraMap.symm

example {E : Type*} [CommRing E] [Algebra k E]
    [Algebra (MvPolynomial (Fin m) k) E]
    [IsScalarTower k (MvPolynomial (Fin m) k) E]
    (φ : (MvPolynomial (Fin m) k ⧸ P) →ₐ[k] E) : True := by
  let oldTower : IsScalarTower k (MvPolynomial (Fin m) k) E := inferInstance
  letI := φ.toRingHom.toAlgebra
  letI : Algebra (MvPolynomial (Fin m) k) E :=
    Algebra.compHom E (algebraMap (MvPolynomial (Fin m) k)
      (MvPolynomial (Fin m) k ⧸ P))
  have : IsScalarTower k (MvPolynomial (Fin m) k) E := oldTower
  trivial
