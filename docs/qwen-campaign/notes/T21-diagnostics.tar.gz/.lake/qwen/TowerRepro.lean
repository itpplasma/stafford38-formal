import Mathlib.RingTheory.MvPolynomial.Basic
import Mathlib.RingTheory.Ideal.Quotient.Operations
import Mathlib.RingTheory.Localization.Away.Basic

variable {k : Type*} [Field k] {m : ℕ}
variable (P : Ideal (MvPolynomial (Fin m) k)) [P.IsPrime]

example : IsScalarTower k (MvPolynomial (Fin m) k)
    (MvPolynomial (Fin m) k ⧸ P) := inferInstance

example {E : Type*} [CommRing E] [Algebra k E]
    (φ : (MvPolynomial (Fin m) k ⧸ P) →ₐ[k] E) :
    letI := φ.toRingHom.toAlgebra
    IsScalarTower k (MvPolynomial (Fin m) k ⧸ P) E := by
  letI := φ.toRingHom.toAlgebra
  exact IsScalarTower.of_algebraMap_eq' φ.comp_algebraMap.symm

/-
The duplicate Algebra (MvPolynomial (Fin m) k) E diagnostic is frozen in
TowerRepro-failing.lean. Its final `oldTower` assignment fails after the
duplicate Algebra.compHom is installed, because the tower's scalar-action
instances differ. That deliberately failing block is omitted here.
-/
