# P5/S5 PDF build receipt

Source paper P5: `75f79630141f2bbeedc4e154288978020c7f2e83`; public formal snapshot S5: `973fa2831cf7520fc42566587e3946b4b7444093`. Formal release R: `54c4f0c902bcd840e44eeba80686ef3fa0e7dc2b` (v1.3.0, DOI 10.5281/zenodo.23126868).

The three PDFs were compiled once with `latexmk -pdf -interaction=nonstopmode -halt-on-error`, in order: `human_readable_main.tex`, `lean_proof_details.tex`, `main.tex`. All commands exited 0; each TeX log has zero undefined citation/reference/control-sequence diagnostics. Exact five TeX/bib input hashes are recorded before and after. `LICENSE.txt` was copied after compilation for the source packet only; README.md is the separate build-instructions input.

See `review-pdfs.json` for complete hashes and build metadata. Human acceptance remains pending.
