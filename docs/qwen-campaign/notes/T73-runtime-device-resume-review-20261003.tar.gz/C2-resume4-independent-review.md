# Independent frozen review: C2 resume4

Verdict: PASS for the narrow resume driver. No source, cache, job, cluster, Lean, or comparator action was performed.

Candidate `/tmp/cluster-final-cache-layout-resume4-20261003.sh` SHA-256: `f88e8e0daf0996638d3fdc687c44b36a2680750c866b1f2b114e49f8a50e6e95`.
Base `/tmp/cluster-final-cache-layout-resume3-20261003.sh` SHA-256: `6fa1ae519128afcbae5253ae3666ae498876ec3f406cb82751b68c383644b85d`.

Reviewed delta is limited to a fresh resume4 receipt directory; an exact R3 job 3136992 finished/exit-1/drained/no-swap gate with outer-log SHA `af8b9780391490b46c4d7cfc2fb01353e84c66238202b7050f4b7779d9007400` and absent R3 receipt directory; and replacing the host-specific `st_dev == 46` pin with the exact expected inode plus runtime checks that donor and target parent share the current device. The relocation records that runtime device/inode and checks the full pair after rename/backlink. Thus the failed node20 device 45 versus prior node device 46 is handled without relaxing cache identity or same-filesystem atomic rename.

All R2 failure/drain checks, inherited R1 verifier receipt/hash, source commit and manifest, clean worktree, original cache symlink/donor containment, exact inode, package pins, four comparator gates, final source identity, and original guard caps remain unchanged. The driver does not repeat successful verifier/module/probe stages. `bash -n` passed. No defect found in the reviewed delta.
