import AlternativeSolution
import Lean.Elab.Command
run_cmd do
  let env ← Lean.getEnv
  for name in env.header.moduleNames do
    Lean.logInfo m!"IMPORT {name}"
