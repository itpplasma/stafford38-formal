#!/bin/bash
set -euo pipefail
RUN=/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815
BW_SRC="$RUN/bootstrap/sources/bubblewrap-v0.12.0"
CAP_SRC="$RUN/bootstrap/sources/libcap-v2.66"
CAP_PREFIX="$RUN/bootstrap/deps/libcap-2.66"
BUILD="$RUN/bootstrap/build/bubblewrap-v0.12.0"
VENV="$RUN/bootstrap/venv/meson-1.3.2"
export PATH="$RUN/bootstrap/bin:$VENV/bin:$PATH"
export PIP_CACHE_DIR="$RUN/bootstrap/pip-cache"
export PKG_CONFIG_PATH="$CAP_PREFIX/lib/pkgconfig${PKG_CONFIG_PATH:+:$PKG_CONFIG_PATH}"
test "$(git -C "$BW_SRC" rev-parse HEAD)" = 2a76602a8c71f36c1527cf9fc3417d9149822e0c
test "$(git -C "$CAP_SRC" rev-parse HEAD)" = 4f96e6788d535da5f57a3452a54b8d92bd41cd8e
test ! -e "$RUN/bootstrap/bin/bwrap"
test ! -e "$BUILD"
python3 -m venv "$VENV"
"$VENV/bin/python" -m pip install --disable-pip-version-check --no-input meson==1.3.2
make -C "$CAP_SRC/libcap" -j2 prefix="$CAP_PREFIX" lib=lib SHARED=no DYNAMIC=no USE_GPERF=no install
pkg-config --modversion libcap
test -f "$CAP_PREFIX/lib/libcap.a"
test -f "$CAP_PREFIX/include/sys/capability.h"
meson setup "$BUILD" "$BW_SRC" --prefix "$RUN/bootstrap" --libdir lib -Dbwrapdir=bin -Dselinux=disabled -Dman=disabled -Dtests=false -Dbash_completion=disabled -Dzsh_completion=disabled
meson compile -C "$BUILD" -j2
meson install -C "$BUILD"
test -x "$RUN/bootstrap/bin/bwrap"
"$RUN/bootstrap/bin/bwrap" --version
test "$("$RUN/bootstrap/bin/bwrap" --version)" = 'bubblewrap 0.12.0'
sha256sum "$RUN/bootstrap/bin/bwrap" "$CAP_PREFIX/lib/libcap.a" "$CAP_PREFIX/lib/pkgconfig/libcap.pc"
ldd "$RUN/bootstrap/bin/bwrap"
"$RUN/bootstrap/bin/bwrap" --ro-bind / / /bin/true
printf 'BWRAP_012_VERSION_AND_READONLY_SANDBOX_PASS\n'
