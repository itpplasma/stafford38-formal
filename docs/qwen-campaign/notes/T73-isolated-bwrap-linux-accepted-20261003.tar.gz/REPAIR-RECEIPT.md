# Isolated bubblewrap 0.12.0 repair

- Slurm job 3128465, scluster node20, two CPUs, 8 GiB requested; `sacct` COMPLETED 0:0, elapsed 00:00:09. The Linux guard ended with exit 0, peak RSS 110,788,608 bytes, zero swap growth, no stop cause, and no surviving descendants.
- Bubblewrap source: official `containers/bubblewrap` v0.12.0, commit `2a76602a8c71f36c1527cf9fc3417d9149822e0c`; binary installed only at `/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/bootstrap/bin/bwrap`, SHA256 `5a42d25969f3f70035d465b51814e02e095e82718514d84e2c97d5b291552fc5`.
- Build tool Meson 1.3.2 is in an isolated venv. Required libcap built static from upstream kernel.org v2.66 commit `4f96e6788d535da5f57a3452a54b8d92bd41cd8e`; archive outputs are in `bootstrap/deps/libcap-2.66`.
- libcap static archive SHA256 `5a99c6df2e87a7a4b9ce35f3d25680d05dc9704a8ff0b339cd57d637a6adb9f0`; pkg-config file SHA256 `53d4ceb8349d5360d42f0583bd973233a37f69c222b8b2b217fd52ff83f7eb12`.
- Checks passed: exact `bubblewrap 0.12.0` version, dynamic dependencies are only libc/loader (`ldd`), and `bwrap --ro-bind / / /bin/true`.
- Build script SHA256 `97c2df9dcec5e01caae336287d21d38eb061cc46c6589e11c4c0deaf102f17af`; guard JSON SHA256 `064a814bc236df851513e80bae95e11250cc1b13a60dd0bf9f448c6fa6a7d6de`.
- Evidence logs and receipts are in this directory. No repository source, system package, or system path was changed. Final driver must prepend `RUN/bootstrap/bin` to PATH to select the isolated binary.
