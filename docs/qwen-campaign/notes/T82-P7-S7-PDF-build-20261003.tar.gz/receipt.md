# P7/S7 PDF build receipt

Paper origin P7 `760c68d2d79a8fd2c4b58f35f32dd90969591300`; public snapshot S7 `9f6ca3241edcf88da42a3a000f25514d105e2f30`. Formal v1.3.1 source R is `f9448d6307fa25aff9d9f94ce0a9c7f9b03e63ff`, DOI `10.5281/zenodo.23127367`. Supplementary v0.2.1 is DOI `10.5281/zenodo.23127468`, published source `6517aa94ac04dfc2cae3b8b89636d631da1cded6`, frozen at P6/S6/R131; this paper update does not advance the supplementary source freeze.

The three PDFs were compiled once with `latexmk -pdf -interaction=nonstopmode -halt-on-error`, in README order. All exited 0 and all TeX logs have zero undefined citation/reference/control-sequence diagnostics. Five TeX/Bib input hashes match before and after; the README hash is separate, and LICENSE.txt was copied after compilation as licensing-only source-packet material. Exact hashes and pins are in `review-pdfs.json`.

Human correspondence reviews remain pending.
