import os
import subprocess
import sys

time_seconds = float(sys.argv[1])
marker = sys.argv[2]
child = subprocess.Popen([sys.executable, "-c", f"import time; time.sleep({time_seconds})"])
with open(marker, "w") as output:
    output.write(f"parent={os.getpid()} child={child.pid} pgid={os.getpgrp()}\n")
    output.flush()
raise SystemExit(7)
