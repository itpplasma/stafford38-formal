import subprocess
import sys
import time

marker = sys.argv[1]
child_code = """import time
size = 600 * 1024 * 1024
buf = bytearray(size)
for offset in range(0, size, 4096):
    buf[offset] = 1
print(f'allocated_bytes={len(buf)}', flush=True)
time.sleep(60)
"""
children = [subprocess.Popen([sys.executable, "-c", child_code]) for _ in range(2)]
with open(marker, "w") as output:
    output.write(" ".join(str(child.pid) for child in children))
    output.flush()
for child in children:
    child.wait()
