import subprocess
import sys

marker = sys.argv[1]
child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
with open(marker, "w") as output:
    output.write(f"parent={__import__('os').getpid()} child={child.pid} pgid={__import__('os').getpgrp()}\n")
    output.flush()
