import os
import subprocess
import sys
import time

mode = sys.argv[1]
if mode == "exit":
    raise SystemExit(int(sys.argv[2]))
if mode == "sleep":
    time.sleep(float(sys.argv[2]))
elif mode == "tree":
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"])
    open(sys.argv[2], "w").write(str(child.pid))
    while True:
        time.sleep(1)
elif mode == "rss":
    size = 1536 * 1024 * 1024
    data = bytearray(size)
    for offset in range(0, size, 4096):
        data[offset] = 1
    print(f"allocated_bytes={len(data)}", flush=True)
    time.sleep(60)
elif mode == "cpu":
    child_code = "import time; end=time.time()+30; x=1;\nwhile time.time()<end: x=(x*3+1)%10000019"
    children = [subprocess.Popen([sys.executable, "-c", child_code]) for _ in range(3)]
    open(sys.argv[2], "w").write(" ".join(str(child.pid) for child in children))
    x = 1
    while True:
        x = (x * 3 + 1) % 10000019
else:
    raise SystemExit(f"unknown mode: {mode}")
