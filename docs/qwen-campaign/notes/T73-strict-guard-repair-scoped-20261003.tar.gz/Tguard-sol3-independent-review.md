# Independent review: strict dependency-guard repair

Verdict: **PASS**, scoped to the exact frozen two-file patch. No Lean command, build, test, or repository edit was performed for this review.

## Frozen inputs

- Base: `45037fbc16329df7a208eb3de91aca31d720f03c`
- Patch: `/tmp/Tguard-sol3.patch`
- Patch SHA-256: `899582b242d69ef2a790cceb39273778c14b763d6084e3577d29ea245e595490`
- Freeze file: `/tmp/Tguard-sol3-freeze.json` (SHA-256 `2893135c891a69197b0ae4d834b2b6af1247e42b35d49f607a23dc9132f7cb1b`)
- Frozen source SHA-256 values match current reviewed files:
  - `scripts/dependency-guard/DependencyClosureCore.lean`: `15fe9e66ff2aad7d58ba6f689c173949690e63212949210e57614b9d503f09c4`
  - `scripts/dependency-guard/run_guard.py`: `0cb12a5252ea5401d4b5c9cd2ff49422a753983ae0046ce56731751f057ca1a4`
- The current two-file Git diff has the reviewed patch SHA above.

## API and logic review

Against the locally installed pinned Lean source at `/home/ert/.elan/toolchains/leanprover--lean4---v4.35.0-rc3/src/lean`:

- `Lean/PrivateName.lean:18-30, 37-50, 52-72` documents and implements `_private.<module>.0 ++ name`, `privatePrefix?`, `privateToUserName`, and `mkPrivateNameCore`. The new owner recovery’s prefix extraction and exact reconstruction check at `DependencyClosureCore.lean:29-39` agree with those APIs; it also rejects anonymous or non-imported owners.
- `Lean/Environment.lean:650-655` confirms `setExporting false` selects the environment’s private-exporting scope. `Environment.getModuleIdxFor?` is at `1196-1198`.
- The patch uses the derived owner only to expand `import all` modules (`run_guard.py:239-253`). It does not waive an unavailable body. `DependencyClosureCore.lean:91-109` still reports absent constants and missing nonstructural definition/theorem/opaque bodies as incomplete; only the existing structural declarations and explicit standard-axiom allowlist retain their prior treatment.
- The runner fails closed for ownerless diagnostics, no new owner progress (including a still-missing body after its owner was imported), and expansion-limit exhaustion (`run_guard.py:240-252`). The expansion cap and old-route diagnostic behavior are unchanged.
- The revised regex at `run_guard.py:24-27` consumes exactly four nonempty tab-delimited fields while excluding CR/LF within fields, so matching is against the full raw diagnostic line. Raw-log capture preserves the unsummarized checker output; it does not affect pass/fail logic.

No defect found in the specified repair. This review does not certify any verifier or comparator receipt; those remain the controller’s separate evidence.
