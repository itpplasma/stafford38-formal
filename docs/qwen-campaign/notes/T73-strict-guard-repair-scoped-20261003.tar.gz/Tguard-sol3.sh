#!/bin/bash
set -euo pipefail
export ELAN_HOME=/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/elan
export PATH="$ELAN_HOME/toolchains/leanprover--lean4---v4.35.0-rc3/bin:$PATH"
cd /home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/final-source
export STAFFORD_DEPENDENCY_GUARD_RAW_LOG=/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/Tguard-sol3-raw.log
python3 scripts/dependency-guard/run_guard.py >/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/Tguard-sol3-production.log 2>&1
python3 tests/dependency-guard-fixtures/test_behavior.py >/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/Tguard-sol3-behavior.log 2>&1
python3 scripts/dependency-guard/run_guard.py --base-module Solution --base-module FixedSourceSolution --route Stafford38Challenge.universalStatement Stafford38.Geometry.SameWitness.coordinate_axis_mem_smooth_fibre_closure Stafford38.Geometry.AlternativeAsymptoticConormal.coordinate_axis_mem_smooth_fibre_closure --route Stafford38FixedSourceChallenge.universalFixedSourceStatement Stafford38.Geometry.SameWitness.coordinate_axis_mem_smooth_fibre_closure Stafford38.Geometry.AlternativeAsymptoticConormal.coordinate_axis_mem_smooth_fibre_closure >/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/Tguard-sol3-mainroutes.log 2>&1
python3 scripts/dependency-guard/run_guard.py --base-module AlternativeSolution --base-module AlternativeFixedSourceSolution --route Stafford38Challenge.universalStatement Stafford38.Geometry.AlternativeAsymptoticConormal.coordinate_axis_mem_smooth_fibre_closure Stafford38.Geometry.SameWitness.coordinate_axis_mem_smooth_fibre_closure --route Stafford38FixedSourceChallenge.universalFixedSourceStatement Stafford38.Geometry.AlternativeAsymptoticConormal.coordinate_axis_mem_smooth_fibre_closure Stafford38.Geometry.SameWitness.coordinate_axis_mem_smooth_fibre_closure >/home/ert/stafford38-campaign/linux-bootstrap-20261003-0815/logs/Tguard-sol3-altroutes.log 2>&1
