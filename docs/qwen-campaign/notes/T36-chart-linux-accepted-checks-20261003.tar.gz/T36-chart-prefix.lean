import Stafford38.Geometry.SameWitness.CommonOpenPositions
import Stafford38.Geometry.PrescribedAffineResidueCompletion

@[expose] public section

set_option autoImplicit false
set_option maxHeartbeats 1600000

noncomputable section

namespace Stafford38.Geometry.SameWitness

open Stafford38.Geometry.PrescribedAffineResidueCompletion

universe u

/-- Package the residue point and two completed unit series over abstract
normalization rings, using the retained coordinate and étale dictionaries. -/
private noncomputable def retainedClosureChartData
    {k B : Type u} [Field k] [CommRing B] {d : ℕ}
    (coeff : k →+* B)
    (fFin : @AlgHom k (MvPolynomial (Option (Fin d)) k) B _ _ _ _ coeff.toAlgebra)
    (hfinite : @Algebra.FiniteType k B _ _ coeff.toAlgebra)
    (M : Ideal B) (hM : M.IsMaximal)
    (eM : letI : Algebra k B := coeff.toAlgebra
      (B ⧸ M) ≃ₐ[k] k)
    (hEtM :
      letI : M.IsMaximal := hM
      let R := MvPolynomial (Option (Fin d)) k
      letI : Algebra k B := coeff.toAlgebra
      letI : Algebra.FiniteType k B := hfinite
      letI : Algebra R B := fFin.toRingHom.toAlgebra
      letI : IsScalarTower k R B := IsScalarTower.of_algHom fFin
      letI : Algebra.EssFiniteType R B := Algebra.EssFiniteType.of_comp k R B
      letI : Algebra R (Localization.AtPrime M) := inferInstance
      Algebra.FormallyEtale R (Localization.AtPrime M))
    (u₀ u₁ : Localization.AtPrime M) :
    ((Fin d → k) × MvPowerSeries (Fin (d + 1)) k) ×
      MvPowerSeries (Fin (d + 1)) k := by
  letI : M.IsMaximal := hM
  let R := MvPolynomial (Option (Fin d)) k
  letI : Algebra k B := coeff.toAlgebra
  letI : Algebra R B := fFin.toRingHom.toAlgebra
  letI : IsScalarTower k R B := IsScalarTower.of_algHom fFin
  letI : Algebra.FiniteType k B := hfinite
  letI : Algebra.EssFiniteType R B := Algebra.EssFiniteType.of_comp k R B
  letI : Algebra R (Localization.AtPrime M) := inferInstance
  letI : Algebra.FormallyEtale R (Localization.AtPrime M) := hEtM
  let chart := pointLocalPowerSeriesChart coeff fFin hfinite M eM hEtM
  exact ((fun z => residueCoordinates M eM (some z), chart u₀), chart u₁)

#print axioms retainedClosureChartData

end Stafford38.Geometry.SameWitness

end
