# Independent review: retained-library resume2

**Verdict: incomplete on one narrow requirement.** Frozen review inputs and the prior failure gates are otherwise consistent with the supplied C2 evidence. No cluster command, Lake build, verifier, comparator, or source edit was run.

## Frozen inputs

- Resume script: `/tmp/cluster-final-retained-library-resume2-20261003.sh`
- SHA-256: `af85aa2cce2aae51092b1fadd6a92497c638f01d900dda799f379425b3a1f540`
- Accepted prior resume script: `docs/qwen-campaign/notes/cluster-final-cache-symlink-resume-20261003.sh`
- Prior-script SHA-256: `5720dadbec8254d7441378935c11a4f67c954e0ca9c4912f18444bf7ce5d2d08`
- Frozen source and manifest: `12ae3cc49152672a48a96f13994314b65ae38197`; `2c697217e318b576775dea866ea45e4e53d1ec3964475953bb4dd5070e08a325`.

## Receipt and scope review

The retained receipt at `/mnt/storage/stafford38-campaign-rc3-20261003/logs/final-C2-resume1-12ae3cc/final-receipts-guard-repaired-resume1/terminal.json` records full verifier exit 0, followed by only the `retained-proof-library` stage failing with 125. The verifier log SHA matches the script’s pinned digest and says “Stafford38 verification passed”; its summary records 317 consumer/import/axiom reports, 111 paper-linked declarations, and 37 permitted-axiom reports. The library log SHA matches its pinned digest and records the invalid aggregate target `proofs` resolving to absent `proofs.lean`, plus a trailing Remote I/O write error. The four comparator stage artifacts are absent. The outer guard records job 3131801 finished with exit 125, no live children, no stop cause, zero swap growth, two CPUs, 8 GiB RSS cap, and 21,600-second cap.

The new script gates on that exact source, failure stage/exit, all prior stage statuses, verifier-log digest and success marker, failed-target diagnostics/digest, absence of comparator receipts, clean exact source HEAD/cache symlink, complete source manifest, Lake-manifest digest, package heads, tooling and prior verifier-output mtimes. It does not rerun the full verifier. The only proof build is the three explicit existing modules, followed by the four comparators and final tracked-source/package-pin checks. Stage timeout remains 19,800 seconds with 60-second kill grace; outer caps are unchanged. `bash -n` passes.

## First defect

`timeout-output-probe` at the end invokes `timeout --kill-after=2s 10s` around a Python process that immediately prints and exits. Thus it checks ordinary stdout/stderr capture under the `timeout` wrapper, but it never reaches the 10-second timeout or exercises output handling on timeout. Because the prior exit 125 included a Remote I/O write failure, this does not satisfy the requested actual timeout/output probe. Make the probe deliberately exceed 10 seconds, capture/assert both pre-timeout streams and the expected timeout status inside a wrapper that itself exits successfully only after those assertions, then continue to the three module targets. Do not weaken gates or label this probe passed in advance.
