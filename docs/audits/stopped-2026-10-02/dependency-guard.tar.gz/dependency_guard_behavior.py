#!/usr/bin/env python3
"""Independent fixture oracle for fail-closed RC3 dependency loading."""

from __future__ import annotations

import os
from pathlib import Path
import subprocess
import tempfile


HERE = Path(__file__).resolve().parent
FIXTURES = HERE / "fixture-src"
RUNNER = HERE / "run_guard.py"
LEAN = Path("/home/ert/.elan/toolchains/leanprover--lean4---v4.35.0-rc3/bin/lean")
LEAN_LIB = LEAN.parent.parent / "lib/lean"


def run(command: list[str], *, cwd: Path, env: dict[str, str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=cwd, env=env, text=True, capture_output=True)


def compile_module(name: str, source: Path, out: Path, env: dict[str, str]) -> None:
    target = out.joinpath(*name.split(".")).with_suffix(".olean")
    target.parent.mkdir(parents=True, exist_ok=True)
    result = run(
        [str(LEAN), "--trust=0", "-j", "1", "--root", str(FIXTURES),
         "-o", str(target), str(source)],
        cwd=FIXTURES, env=env,
    )
    if result.returncode:
        raise RuntimeError(f"fixture compile failed for {name}:\n{result.stdout}{result.stderr}")


def run_fixture(out: Path, root: str, producer: str, module: str) -> subprocess.CompletedProcess[str]:
    return run(
        ["python3", str(RUNNER), "--fixture", "--fixture-root-name", root,
         "--forbidden-name", producer, "--base-module", module,
         "--extra-lean-path", str(out)],
        cwd=HERE, env=os.environ.copy(),
    )


def run_production_fixture(out: Path) -> subprocess.CompletedProcess[str]:
    return run(
        ["python3", str(RUNNER), "--fixture-production",
         "--base-module", "Challenge", "--base-module", "Solution",
         "--base-module", "FixedSourceChallenge", "--base-module", "FixedSourceSolution",
         "--extra-lean-path", str(out)],
        cwd=HERE, env=os.environ.copy(),
    )


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="stafford-guard-fixtures-") as temporary:
        out = Path(temporary).resolve()
        env = os.environ.copy()
        env["LEAN_PATH"] = os.pathsep.join((str(out), str(LEAN_LIB)))

        core = HERE / "DependencyClosureCore.lean"
        core_build = run(
            [str(LEAN), "--trust=0", "-j", "1", "--root", str(HERE),
             "-o", str(out / "DependencyClosureCore.olean"), str(core)],
            cwd=HERE, env=env,
        )
        if core_build.returncode:
            raise RuntimeError(f"core compile failed:\n{core_build.stdout}{core_build.stderr}")

        for name in ("GuardFixtureSafe", "GuardFixtureMissingBody", "GuardFixtureBad",
                     "GuardFixtureBannedOwner", "GuardFixtureRelay", "GuardFixtureBadRoot"):
            compile_module(name, FIXTURES / f"{name}.lean", out, env)
        production_modules = (
            "Stafford38.Geometry.GeneralAsymptoticLaurentAxis",
            "Stafford38.Geometry.GeneralConormalAxis",
            "Stafford38.Geometry.CanonicalNonconstantFiniteGradientProductionProof",
            "Challenge", "Solution", "FixedSourceSolution", "FixedSourceChallenge",
        )
        for name in production_modules:
            compile_module(name, FIXTURES.joinpath(*name.split(".")).with_suffix(".lean"), out, env)

        positive = run_fixture(
            out, "GuardFixture.safeTerminal", "GuardFixture.forbiddenProducer", "GuardFixtureSafe"
        )
        if positive.returncode != 0 or "forbidden hits: 0" not in positive.stdout + positive.stderr:
            raise RuntimeError(f"safe positive fixture failed:\n{positive.stdout}{positive.stderr}")

        negative = run_fixture(
            out, "GuardFixture.transitiveBadTerminal",
            "GuardFixture.transitiveForbiddenProducer", "GuardFixtureBadRoot",
        )
        negative_output = negative.stdout + negative.stderr
        if negative.returncode == 0 or "transitiveForbiddenProducer" not in negative_output:
            raise RuntimeError(f"transitive forbidden producer escaped:\n{negative_output}")
        if "body_load_round=1" not in negative_output or "GuardFixtureRelay" not in negative_output:
            raise RuntimeError(f"runner did not expand missing opaque-body owner:\n{negative_output}")

        unavailable = run_fixture(
            out, "GuardFixtureMissing.terminal", "GuardFixture.forbiddenProducer",
            "GuardFixtureMissingBody",
        )
        unavailable_output = unavailable.stdout + unavailable.stderr
        if unavailable.returncode == 0 or "bodyless axiom is not on the explicit standard-axiom allowlist" not in unavailable_output:
            raise RuntimeError(f"unapproved bodyless axiom was not rejected:\n{unavailable_output}")

        production = run_production_fixture(out)
        production_output = production.stdout + production.stderr
        if production.returncode == 0:
            raise RuntimeError(f"production guard accepted fixture's forbidden old route:\n{production_output}")
        if "GeneralAsymptoticLaurentAxis" not in production_output:
            raise RuntimeError(f"production guard missed forbidden old module owner:\n{production_output}")
        if "exists_groundConormalAxis_of_minimalPrime_unit_transcendental" not in production_output:
            raise RuntimeError(f"production guard missed the exact banned producer:\n{production_output}")

    print("PASS: safe closure accepted; opaque/private transitive producer rejected after owner expansion; unapproved axiom fails closed; four-root RC3 command rejects exact banned producer/module")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
