module
public import Stafford38.Geometry.GeneralConormalAxis

@[expose] public section

namespace Stafford38

opaque universalStatement : True :=
  Stafford38.Geometry.GeneralConormalAxis.exists_groundConormalAxis_of_minimalPrime_unit_transcendental

end Stafford38
