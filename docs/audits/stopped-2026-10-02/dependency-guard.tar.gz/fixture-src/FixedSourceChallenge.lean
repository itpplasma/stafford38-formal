module
public import FixedSourceSolution

@[expose] public section

namespace Stafford38FixedSourceChallenge

theorem universalFixedSourceStatement : True := Stafford38.universalFixedSourceStatement

end Stafford38FixedSourceChallenge
