module
public import Lean

@[expose] public section

namespace GuardFixture

def transitiveForbiddenProducer : Nat := 9

end GuardFixture
