module
public import Stafford38.Geometry.CanonicalNonconstantFiniteGradientProductionProof

@[expose] public section

namespace Stafford38

opaque universalFixedSourceStatement : True :=
  Stafford38.Geometry.CanonicalNonconstantFiniteGradientProductionProof.exists_groundConormalAxis_of_regularizedOneRowConormalData

end Stafford38
