module
public import Lean

@[expose] public section

namespace GuardFixtureMissing

axiom unavailableProducer : Nat
theorem terminal : unavailableProducer = unavailableProducer := rfl

end GuardFixtureMissing
