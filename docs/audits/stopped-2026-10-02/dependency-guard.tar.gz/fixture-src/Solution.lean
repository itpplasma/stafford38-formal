module
public import Challenge

@[expose] public section

namespace Stafford38Challenge

theorem universalStatement : True := Stafford38.universalStatement

end Stafford38Challenge
