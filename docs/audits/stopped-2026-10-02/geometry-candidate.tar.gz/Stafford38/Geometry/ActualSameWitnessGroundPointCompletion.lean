import Stafford38.Geometry.ActualSameWitnessDivisorNumerator
import Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
import Stafford38.Geometry.GroundPointETCompatibility
import Stafford38.Geometry.ActualOptionGroundPointCompletion
import Stafford38.Geometry.ChartGenericPointFractionRing
import Stafford38.Geometry.ProjectiveChartNormalizationFinite
import Stafford38.Geometry.IntegralClosureCenterDVR
import Stafford38.Geometry.ActualChartValuationImage
import Stafford38.Geometry.RetainedGroundMapIdentification
import Stafford38.Geometry.ComponentFunctionFieldBoundary
import Stafford38.Geometry.UnitPowerCenterTransport

set_option autoImplicit false
set_option maxHeartbeats 4000000
set_option synthInstance.maxHeartbeats 600000
set_option linter.style.haveILetI false
set_option pp.explicit false

noncomputable section

namespace Stafford38.Geometry.ActualSameWitnessGroundPointCompletion

open IsLocalRing
open Stafford38.Geometry.AsymptoticDivisorExistence
open Stafford38.Geometry.AsymptoticChartArcAdapter
open Stafford38.Geometry.ComponentProjectiveClosure
open Stafford38.Geometry.ComponentProjectiveChartKernel
open Stafford38.Geometry.ComponentFunctionFieldBoundary
open Stafford38.Geometry.GeneralDivisorialVisibleFrame
open Stafford38.Geometry.RelativeCoefficientDVR
open Stafford38.Geometry.RelativeRetainedBoundaryPlace
open Stafford38.Geometry.ChartGenericPointFractionRing
open Stafford38.Geometry.ProjectiveChartNormalizationCenter
open Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
open Stafford38.Geometry.ActualOptionColumnBinding
open Stafford38.Geometry.ActualSameWitnessDivisorNumerator
open Stafford38.Geometry.RetainedGroundMapIdentification

universe u

/-- Exact output of the actual same-witness selected chart construction. This is a named
proposition so the dependent telescope is elaborated once and downstream callers can
refer to the canonical package without re-expanding its instance-heavy lets. -/
@[irreducible] def actualSameWitnessGroundPointOutput
    {k : Type u} [Field k] [CharZero k] [IsAlgClosed k]
    {m : ℕ} (hm : 0 < m)
    (P : PrimeSpectrum (MvPolynomial (Fin m) k))
    (w : GeneralDivisorialVisibleFrameWitness hm P) : Prop :=
  let C := w.column
  let W := C.W
  let F := ComponentFractionField P
  letI : Algebra (CoordinateZeroLocalRing W.coefficientField) F := W.ambientAlgebra
  let U := W.place.valuation
  let V := U.toSubring
  letI : IsDiscreteValuationRing V := W.place.isDiscrete
  letI : IsLocalRing V := W.place.isDiscrete.toIsLocalRing
  letI : Algebra W.coefficientField V :=
    (relativeCoefficientMap W.coefficientField W.place).toAlgebra
  let κ := ResidueField V
  letI : Algebra k κ := retainedResidueGroundAlgebra P ⟨0, hm⟩ W
  let hQV :=
    ActualChartValuationImage.chartGenericPointSubalgebra_le_valuationSubring hm P w
  let B := actualSelectedNormalization P w
  let coeff := actualSelectedNormalizationCoefficients P w
  letI : Algebra k B := coeff.toAlgebra
  let PB := actualSelectedNormalizationCenterPrime P w hQV
  ∃ (hBfinite : Algebra.FiniteType k B),
    letI : Algebra.FiniteType k B := hBfinite
    ∃ (t : Set κ) (htFinite : t.Finite),
    letI : Fintype t := htFinite.fintype
    ∃ (htBasis : IsTranscendenceBasis k ((↑) : t → κ))
      (index : t → Fin m), Function.Injective index ∧
      (∀ z : t, residue V
        (C.q ((chartAffineCoordinateEquiv C.chart) (index z)).1) = (z : κ)) ∧
      ∃ (hPB : PB.IsPrime),
        letI : PB.IsPrime := hPB
        ∃ (s : B) (hs0 : s ≠ 0) (hsPB : s ∈ PB)
          (u₀ u₁ : Localization.AtPrime PB)
          (hu₀ : IsUnit u₀) (hu₁ : IsUnit u₁)
          (hspan : Ideal.span {algebraMap B (Localization.AtPrime PB) s} =
            maximalIdeal (Localization.AtPrime PB))
          (hfactor₀ :
            algebraMap B (Localization.AtPrime PB)
                (actualNormalizedProjectiveColumnInIntegralClosure hm P w 0) =
              (algebraMap B (Localization.AtPrime PB) s) ^
                w.differential.core.D.a * u₀)
          (hfactor₁ :
            algebraMap B (Localization.AtPrime PB)
                (actualNormalizedProjectiveColumnInIntegralClosure hm P w
                  (Fin.succ ⟨0, hm⟩)) =
              (algebraMap B (Localization.AtPrime PB) s) ^
                (w.differential.core.D.a + w.differential.core.D.e) * u₁),
          let rows := actualSelectedNormalizationRows P w index
          let fOption : MvPolynomial (Option t) k →ₐ[k] B :=
            MvPolynomial.aeval (fun j : Option t =>
              match j with
              | none => s
              | some z => rows z)
          ∃ (cert : ActualOptionEtaleCertificate k t B PB s rows fOption),
            ActualOptionGroundPointCompletion.GroundPointChartOutput
              PB fOption s
              (actualNormalizedProjectiveColumnInIntegralClosure hm P w 0)
              (actualNormalizedProjectiveColumnInIntegralClosure hm P w
                (Fin.succ ⟨0, hm⟩))
              (actualSelectedNormalizationRows P w index)
              ((Fintype.equivFin t).symm)
              w.differential.core.D.a
              (w.differential.core.D.a + w.differential.core.D.e)


end Stafford38.Geometry.ActualSameWitnessGroundPointCompletion
