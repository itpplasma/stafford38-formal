import Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
import Stafford38.Geometry.ActualWitnessSelectedChartIndex
import Stafford38.Geometry.ChartGenericPointFractionRing
import Stafford38.Geometry.ComponentProjectiveClosure

set_option autoImplicit false
set_option maxHeartbeats 4000000

noncomputable section

namespace Stafford38.Geometry.ActualChartNormalizationTypeAlignment

open Stafford38.Geometry.GeneralDivisorialVisibleFrame
open Stafford38.Geometry.ActualSelectedNormalizationDivisorEtale
open Stafford38.Geometry.ChartGenericPointFractionRing
open Stafford38.Geometry.ComponentProjectiveClosure

universe u

/-- The integral closure attached to the retained column agrees with the
selected affine-chart closure after the checked chart-index identification. -/
theorem actual_selected_normalization_eq_selected_chart
    {k : Type u} [Field k] [CharZero k] {m : ℕ} {hm : 0 < m}
    (P : PrimeSpectrum (MvPolynomial (Fin m) k))
    (w : GeneralDivisorialVisibleFrameWitness hm P)
    (j : Fin m) (hchart : w.column.chart = Fin.succ j) :
    actualSelectedNormalization P w =
      integralClosure
        ((Algebra.adjoin k (Set.range
          (chartGenericPoint P (Fin.succ j) (SelectedAffineCoordinateEquiv j)))).toSubring)
        (ComponentFractionField P) := by
  classical
  dsimp [actualSelectedNormalization, actualSelectedChartAlgebra]
  rw [hchart]

end Stafford38.Geometry.ActualChartNormalizationTypeAlignment

end
