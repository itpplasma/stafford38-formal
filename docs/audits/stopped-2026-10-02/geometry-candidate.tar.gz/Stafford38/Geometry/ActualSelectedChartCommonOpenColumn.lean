import Stafford38.Geometry.A0NormalizedProjectiveCoordinates

set_option autoImplicit false
set_option maxHeartbeats 4000000
set_option linter.style.haveILetI false

noncomputable section

namespace Stafford38.Geometry.ActualSelectedChartCommonOpenColumn

open Stafford38.Geometry.ProjectiveChartSameFieldOverlap
open Stafford38.Geometry.A0ChartFormalEtale
open Stafford38.Geometry.A0ChartGeneratorCoordinates
open Stafford38.Geometry.A0NormalizedProjectiveCoordinates
open Stafford38.Geometry.EtaleGenericOpenTransport
open Stafford38.Geometry.ComponentProjectiveChartKernel
open Stafford38.Geometry.AffineComponentCoordinateSplit

universe u v w

/-- A projective column in any selected-chart algebra has the standard
original-affine coordinates after passage to the common open. -/
theorem q_column_commonOpen_coordinates
    {k : Type u} [Field k] {m : ℕ}
    {Q : Type v} [CommRing Q] [Algebra k Q]
    {B : Type w} [CommRing B] [Algebra Q B]
    (P : PrimeSpectrum (MvPolynomial (Fin m) k)) (j : Fin m)
    (hxj : componentCoordinate P j ≠ 0)
    (hsel : SelectedAffineChartQuotient (k := k) P j ≃ₐ[k] Q)
    (M : Ideal B) [M.IsPrime] (f : Q)
    (e : Localization.Away f ≃ₐ[Q]
      Localization.Away (algebraMap Q B f))
    (qQ : Fin (m + 1) → Q)
    (hchart : qQ (Fin.succ j) = 1)
    (hzero : qQ 0 = hsel (selectedAffineChartDenominator P j))
    (hrows : ∀ i : Fin m, ∀ hij : i ≠ j,
      qQ (Fin.succ i) = hsel (selectedAffineChartVariableClass P j i hij)) :
    let g := hsel (selectedAffineChartDenominator P j)
    let Cq := genericOpenRing M f e
    let C := genericOpenExtraAwayB M f e g
    letI : Semiring C := (inferInstance : CommSemiring C).toSemiring
    letI : Algebra Q Cq := inferInstance
    letI : Algebra Cq C := inferInstance
    letI : Algebra Q C := Algebra.compHom C (algebraMap Q Cq)
    let qU : Fin (m + 1) → C := fun i =>
      algebraMap Cq C (algebraMap Q Cq (qQ i))
    ∀ i : Fin m,
      qU (Fin.succ i) = qU 0 *
        originalAffineChartToCommonOpen P j hxj hsel M f e
          (Ideal.Quotient.mk P.asIdeal (MvPolynomial.X i)) := by
  classical
  dsimp
  let g := hsel (selectedAffineChartDenominator P j)
  let Cq := genericOpenRing M f e
  let C := genericOpenExtraAwayB M f e g
  letI : Semiring C := (inferInstance : CommSemiring C).toSemiring
  letI : Algebra Q Cq := inferInstance
  letI : Algebra Cq C := inferInstance
  letI : Algebra Q C := Algebra.compHom C (algebraMap Q Cq)
  let R := SelectedAffineChartQuotient (k := k) P j
  let S := SelectedAffineChartLocalization (k := k) P j
  let T := Localization.Away g
  let A₀ := OriginalAffineChartQuotient (k := k) P
  let S₀ := OriginalAffineChartLocalization (k := k) P j
  let Mpow := Submonoid.powers (selectedAffineChartDenominator P j)
  let N := Submonoid.powers g
  letI : IsLocalization Mpow S := Localization.isLocalization
  letI : IsLocalization.Away
      (hsel.toRingEquiv.toRingHom (selectedAffineChartDenominator P j)) T :=
    Localization.isLocalization
  have hmap : Submonoid.map hsel Mpow = N := by
    simp [Mpow, N, g, Submonoid.map_powers]
  let E := selectedChartAwayEquivOfQuotientEquiv P j hsel
  have hbase : E (algebraMap R S (selectedAffineChartDenominator P j)) =
      algebraMap Q T g := by
    change IsLocalization.algEquivOfAlgEquiv
      (S := S) (Q := T) (h := hsel) hmap
      (algebraMap R S (selectedAffineChartDenominator P j)) = _
    exact IsLocalization.algEquivOfAlgEquiv_eq
      (S := S) (Q := T) (h := hsel) hmap
      (selectedAffineChartDenominator P j)
  have hz : genericOpenBMap M f e (algebraMap Q B g) = algebraMap Q Cq g :=
    genericOpenBMap_base_eq M f e g
  letI : IsLocalization.Away (algebraMap Q Cq g) C := by
    rw [← hz]
    infer_instance
  let ψ : T →+* C := IsLocalization.Away.map
    (S := T) (Q := C) (algebraMap Q Cq) g
  have hprod : algebraMap Q T g *
      E (IsLocalization.Away.invSelf (selectedAffineChartDenominator P j)) = 1 := by
    calc
      _ = E (algebraMap R S (selectedAffineChartDenominator P j)) *
          E (IsLocalization.Away.invSelf (selectedAffineChartDenominator P j)) := by
            rw [hbase]
      _ = E (algebraMap R S (selectedAffineChartDenominator P j) *
          IsLocalization.Away.invSelf (selectedAffineChartDenominator P j)) := by
            rw [← map_mul]
      _ = E 1 := by rw [IsLocalization.Away.mul_invSelf]
      _ = 1 := map_one _
  have hψg : ψ (algebraMap Q T g) = algebraMap Cq C (algebraMap Q Cq g) := by
    simp [ψ, IsLocalization.Away.map]
  have hXj : originalAffineChartToCommonOpen P j hxj hsel M f e
      (Ideal.Quotient.mk P.asIdeal (MvPolynomial.X j)) =
      ψ (E (IsLocalization.Away.invSelf (selectedAffineChartDenominator P j))) := by
    change ψ (E ((originalAffineChartOverlapEquiv P j hxj)
      (algebraMap A₀ S₀
        (Ideal.Quotient.mk P.asIdeal (MvPolynomial.X j))) )) = _
    rw [originalAffineChartOverlapEquiv_Xj]
  have hselected : algebraMap Cq C (algebraMap Q Cq g) *
      originalAffineChartToCommonOpen P j hxj hsel M f e
        (Ideal.Quotient.mk P.asIdeal (MvPolynomial.X j)) = 1 := by
    calc
      _ = ψ (algebraMap Q T g) *
          ψ (E (IsLocalization.Away.invSelf (selectedAffineChartDenominator P j))) := by
            rw [hψg, hXj]
      _ = ψ (algebraMap Q T g *
          E (IsLocalization.Away.invSelf (selectedAffineChartDenominator P j))) := by
            rw [map_mul]
      _ = 1 := by rw [hprod]; simp
  intro i
  by_cases hij : i = j
  · subst i
    simpa [hzero, hchart] using hselected.symm
  · have hother := originalGenerator_commonOpen_identity
      P j i hij hxj hsel M f e
    simpa [hzero, hrows i hij] using hother

end Stafford38.Geometry.ActualSelectedChartCommonOpenColumn
