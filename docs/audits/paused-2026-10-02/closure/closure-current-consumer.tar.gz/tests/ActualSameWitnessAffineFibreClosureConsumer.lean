import Stafford38.Geometry.ActualSameWitnessAffineFibreClosure
import Stafford38.Geometry.GenericSmoothOpen

set_option autoImplicit false
set_option maxHeartbeats 4000000

namespace Stafford38ActualSameWitnessClosureConsumer

universe u

/-- An external consumer states the original affine-conormal conclusion
without assuming a smooth chart or any column, derivative, numerator,
or closure identity. It constructs the named ground-point output from
the retained visible-frame witness. -/
theorem axis_in_original_affine_conormal_fibre_closure
    {k : Type u} [Field k] [CharZero k] [IsAlgClosed k]
    {m : ℕ} (hm : 0 < m)
    (P : PrimeSpectrum (MvPolynomial (Fin m) k))
    (w : Stafford38.Geometry.GeneralDivisorialVisibleFrame.GeneralDivisorialVisibleFrameWitness
      hm P) :
    (fun i : Fin m => if i = (⟨0, hm⟩ : Fin m) then (1 : k) else 0) ∈
      MvPolynomial.zeroLocus k
        (MvPolynomial.vanishingIdeal k
          (Stafford38.Geometry.ProjectiveConormalDirections.smoothConormalFibreProjection
            P.asIdeal)) := by
  exact Stafford38.Geometry.ActualSameWitnessAffineFibreClosure.axis_mem_smoothConormalFibreProjection_closure_of_groundPointOutput
    hm P w
    (Stafford38.Geometry.ActualSameWitnessGroundPointCompletion.exists_actual_same_witness_groundpoint_chart
      hm P w)
    (Stafford38.Geometry.exists_nonzero_smooth_away_quotient P.asIdeal)

#print axioms axis_in_original_affine_conormal_fibre_closure
#print axioms Stafford38.Geometry.ActualSameWitnessAffineFibreClosure.axis_mem_smoothConormalFibreProjection_closure_of_groundPointOutput

end Stafford38ActualSameWitnessClosureConsumer
